<?php

if(isset($_POST['LibBook'])){
  
 WC()->session->set( 'LibBook', '1363' );
}