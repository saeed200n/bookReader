
<?php
/* Template Name: landBFull */


$servername = "db5011042605.hosting-data.io";
$username = "dbu5510833";
$password = "Ss09120127028";
$dbname = "dbs9333543";
$mydb = new wpdb($username,$password,$dbname,$servername);

get_header();

try {
if(isset($_SESSION['pid'])){
    $pid=$_SESSION['pid'];
    $sql="SELECT * FROM bookReader WHERE id_product LIKE $pid;";
    $q=$mydb->get_results($sql);
    
foreach ($q as $obj) :
$id_dflip=$obj->id_dflip;
  echo '<div id="boxReader">';
echo do_shortcode("[dflip id=".$id_dflip." ][/dflip]");
  echo '</div>';
endforeach;


}
} catch (PDOException $e) {
    echo "check exist table fehlgeschlagen" . "-" . $e->getmessage();

}

?>

<?php

get_footer();
?>
